#!/bin/sh
curl -f http://localhost:3000/ || exit 1
