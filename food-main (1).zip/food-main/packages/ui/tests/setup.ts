/// <reference types="@vitest/browser/providers/playwright" />

import { beforeAll } from 'vitest'

beforeAll(() => {
  // Setup code
})
