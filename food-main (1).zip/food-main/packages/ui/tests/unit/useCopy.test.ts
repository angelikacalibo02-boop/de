import { describe, expect, it } from 'vitest'

describe('useCopy', () => {
  it('should work', () => {
    expect(true).toMatchInlineSnapshot(`true`)
  })
})
