import { z } from 'zod'

export const locale = z.enum(['en', 'ru'])
