# Core Nuxt Layer

Details see https://nuxt.com/docs/getting-started/layers
