<template>
  <div class="shrink-0 flex items-center gap-1.5 px-6">
    <h2 class="font-semibold text-xl text-highlighted">
      {{ $t('app.title') }}
    </h2>
  </div>
</template>
