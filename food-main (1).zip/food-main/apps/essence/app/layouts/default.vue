<template>
  <div class="fixed inset-0 flex overflow-hidden">
    <div class="hidden lg:flex flex-col min-h-svh min-w-16 w-72 border-r border-default shrink-0 bg-elevated/25">
      <NavigationHeader class="h-16" />
      <Navigation />
    </div>

    <main class="flex flex-col min-w-0 min-h-svh lg:not-last:border-r lg:not-last:border-default flex-1">
      <slot />
    </main>
  </div>

  <USlideover
    v-model:open="isNavbarOpened"
    side="left"
  >
    <template #header>
      <div class="flex flex-row items-center">
        <UButton
          icon="i-lucide-x"
          color="neutral"
          variant="ghost"
          @click="isNavbarOpened = false"
        />

        <NavigationHeader />
      </div>
    </template>

    <template #body>
      <Navigation />
    </template>
  </USlideover>
</template>

<script setup lang="ts">
const { isNavbarOpened } = useApp()
</script>
