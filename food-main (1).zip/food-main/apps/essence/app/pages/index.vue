<template>
  123
</template>

<script setup lang="ts">
definePageMeta({
  middleware: ['02-staff'],
})
</script>
