<template>
  <UApp :tooltip="{ delayDuration: 0 }">
    <Header transparent />
    <NuxtPage />
  </UApp>
</template>
