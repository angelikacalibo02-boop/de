<template>
  <UTooltip text="GitHub">
    <UButton
      to="https://github.com/nextorders/food"
      target="_blank"
      leading-icon="food:github"
      aria-label="GitHub"
      variant="ghost"
      color="primary"
      size="xl"
      class="px-2 py-2 gap-2"
    >
      33
    </UButton>
  </UTooltip>
</template>
