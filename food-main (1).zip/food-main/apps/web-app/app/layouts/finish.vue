<template>
  <main class="relative top-16 min-h-dvh">
    <UContainer class="pb-10 pt-4 max-w-2xl">
      <slot />
    </UContainer>

    <div class="pb-10 max-w-2xl mx-auto">
      <Footer />
    </div>
  </main>
</template>
