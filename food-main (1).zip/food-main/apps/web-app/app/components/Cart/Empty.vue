<template>
  <div class="mt-8">
    <NuxtImg
      src="/img/eggs-192.png"
      alt=""
      class="mx-auto mb-2 size-24 opacity-60 grayscale"
    />
    <div class="text-lg text-center font-normal text-muted">
      {{ $t('app.cart.empty-label') }}
    </div>
  </div>
</template>
