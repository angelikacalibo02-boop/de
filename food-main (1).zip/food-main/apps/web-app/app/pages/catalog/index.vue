<template>
  <div />
</template>

<script setup lang="ts">
// There will be catalog page if index page is busy
await navigateTo('/')
</script>
